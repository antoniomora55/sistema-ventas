<?php
$connection = mysqli_connect(
  'localhost',
  'root',
  'NewPassword',
  'mi_sistema'
) or die(mysqli_erro($mysqli));

?>